# Official dark solarized colorscheme

http://ethanschoonover.com/solarized
