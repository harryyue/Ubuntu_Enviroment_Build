# Dark solarized alternative, by reychino (Reinaldo Zapata)

Dark solarized colorscheme fork, with a different palette, to avoid the
"invisible" text bug.
